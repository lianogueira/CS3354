/** This package contains classes and methods for handling a Shipping Store and its packages and users
 @author Lia Nogueira de Moura / Tyler Hooks 
 */
package shippingstore;